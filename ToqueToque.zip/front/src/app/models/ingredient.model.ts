export interface Ingredient {
  _id: string;
  name: string;
  category: string;
  image: string;
}
